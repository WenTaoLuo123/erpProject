package com.xt.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xt.pojo.SPay;
import com.xt.util.PageUtil;

/**
 * 出库
 * @author 罗文涛
 *
 */
public interface SPayMapper {
	/**
	 * 分页查询出库
	 * @param page
	 * @param s
	 * @return
	 */
	List<SPay> spaylist(@Param("page") PageUtil page,@Param("s") SPay s); 
	int countSPay(@Param("s")SPay s);
	/**
	 * 添加出库单
	 * @param s
	 * @return
	 */
	int addSPay(SPay s);
	
}
