package com.xt.pojo;

import java.io.Serializable;

/**
 * 产品生产计划实体类
 *
 * @author makejava
 * @since 2020-04-17 10:35:17
 */
public class MApply implements Serializable {
    private static final long serialVersionUID = 311706657090918042L;
    //序号
    private Integer id;
    //生产计划编号
    private String apply_Id;
    //产品编号
    private String product_Id;
    //产品名称
    private String product_Name;
    //产品描述
    private String product_Describe;
    //用途类型
    private String type;
    //数量
    private Object amount;
    //设计人
    private String designer;
    //备注
    private String remark;
    //登记人
    private String register;
    //登记时间
    private Object register_Time;
    //复核人
    private String checker;
    //审核意见
    private String check_Suggestion;
    //审核时间
    private Object check_Time;
    //审核标志    S001-0: 等待审核    S001-1: 审核通过   S001-2: 审核不通过
    private String check_Tag;
    //派工标志    P001-0: 未派工     P001-1: 已派工
    private String manufacture_Tag;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getApply_Id() {
		return apply_Id;
	}
	public void setApply_Id(String apply_Id) {
		this.apply_Id = apply_Id;
	}
	public String getProduct_Id() {
		return product_Id;
	}
	public void setProduct_Id(String product_Id) {
		this.product_Id = product_Id;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public String getProduct_Describe() {
		return product_Describe;
	}
	public void setProduct_Describe(String product_Describe) {
		this.product_Describe = product_Describe;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Object getAmount() {
		return amount;
	}
	public void setAmount(Object amount) {
		this.amount = amount;
	}
	public String getDesigner() {
		return designer;
	}
	public void setDesigner(String designer) {
		this.designer = designer;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRegister() {
		return register;
	}
	public void setRegister(String register) {
		this.register = register;
	}
	public Object getRegister_Time() {
		return register_Time;
	}
	public void setRegister_Time(Object register_Time) {
		this.register_Time = register_Time;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public String getCheck_Suggestion() {
		return check_Suggestion;
	}
	public void setCheck_Suggestion(String check_Suggestion) {
		this.check_Suggestion = check_Suggestion;
	}
	public Object getCheck_Time() {
		return check_Time;
	}
	public void setCheck_Time(Object check_Time) {
		this.check_Time = check_Time;
	}
	public String getCheck_Tag() {
		return check_Tag;
	}
	public void setCheck_Tag(String check_Tag) {
		this.check_Tag = check_Tag;
	}
	public String getManufacture_Tag() {
		return manufacture_Tag;
	}
	public void setManufacture_Tag(String manufacture_Tag) {
		this.manufacture_Tag = manufacture_Tag;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public MApply(Integer id, String apply_Id, String product_Id, String product_Name, String product_Describe,
			String type, Object amount, String designer, String remark, String register, Object register_Time,
			String checker, String check_Suggestion, Object check_Time, String check_Tag, String manufacture_Tag) {
		super();
		this.id = id;
		this.apply_Id = apply_Id;
		this.product_Id = product_Id;
		this.product_Name = product_Name;
		this.product_Describe = product_Describe;
		this.type = type;
		this.amount = amount;
		this.designer = designer;
		this.remark = remark;
		this.register = register;
		this.register_Time = register_Time;
		this.checker = checker;
		this.check_Suggestion = check_Suggestion;
		this.check_Time = check_Time;
		this.check_Tag = check_Tag;
		this.manufacture_Tag = manufacture_Tag;
	}
	public MApply() {
		super();
	}
	@Override
	public String toString() {
		return "MApply [id=" + id + ", apply_Id=" + apply_Id + ", product_Id=" + product_Id + ", product_Name="
				+ product_Name + ", product_Describe=" + product_Describe + ", type=" + type + ", amount=" + amount
				+ ", designer=" + designer + ", remark=" + remark + ", register=" + register + ", register_Time="
				+ register_Time + ", checker=" + checker + ", check_Suggestion=" + check_Suggestion + ", check_Time="
				+ check_Time + ", check_Tag=" + check_Tag + ", manufacture_Tag=" + manufacture_Tag + "]";
	}


}