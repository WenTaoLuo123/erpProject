package com.xt.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xt.pojo.MDesignProcedureDetails;

public interface MDesignProcedureDetailsService {
	/**
	 * 产品设计详情
	 * @return
	 */
	List<MDesignProcedureDetails> findList(String parent_Id);
	/**
	 * 修改产品设计详情
	 * @param md
	 * @return
	 */
	int updatemdesignDetails(MDesignProcedureDetails md);
	/**
	 * 添加产品设计详情
	 * @param md
	 * @return
	 */
	int addmdesignDetails(MDesignProcedureDetails md);
}
