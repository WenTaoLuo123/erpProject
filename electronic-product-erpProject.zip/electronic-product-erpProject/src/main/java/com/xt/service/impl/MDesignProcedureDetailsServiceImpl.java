package com.xt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xt.mapper.MDesignProcedureDetailsMapper;
import com.xt.pojo.MDesignProcedureDetails;
import com.xt.service.MDesignProcedureDetailsService;

/**
 * 产品设计详情业务类
 * @author 罗文涛
 */
@Service
public class MDesignProcedureDetailsServiceImpl implements MDesignProcedureDetailsService {
	@Autowired
	MDesignProcedureDetailsMapper mapper;
	@Override
	public List<MDesignProcedureDetails> findList(String parent_Id) {
		// TODO Auto-generated method stub
		return mapper.findList(parent_Id);
	}

	@Override
	public int updatemdesignDetails(MDesignProcedureDetails md) {
		// TODO Auto-generated method stub
		return mapper.updatemdesignDetails(md);
	}

	@Override
	public int addmdesignDetails(MDesignProcedureDetails md) {
		// TODO Auto-generated method stub
		return mapper.addmdesignDetails(md);
	}

}
