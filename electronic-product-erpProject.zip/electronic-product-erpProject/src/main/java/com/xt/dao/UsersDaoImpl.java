package com.xt.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UsersDaoImpl implements UsersDao{
	
}
