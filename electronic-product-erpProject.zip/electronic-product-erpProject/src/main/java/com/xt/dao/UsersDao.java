package com.xt.dao;

public interface UsersDao {

}
