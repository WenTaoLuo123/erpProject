package com.xt.controller;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.xt.pojo.MDesignProcedure;
import com.xt.pojo.MDesignProcedureDetails;
import com.xt.service.MDesignProcedureDetailsService;
import com.xt.service.MDesignProcedureService;
import com.xt.util.OrderNo;
import com.xt.util.PageDemo;
/**
 * 产品设计控制类
 * @author asus
 *罗文涛
 */
@Controller
public class MDesignProcedureController {
	@Autowired
	MDesignProcedureService serivce;
	@Autowired
	MDesignProcedureDetailsService mdserivce;
	/**
	 * 审核标志   S001-0: 等待审核     S001-1: 审核通过    S001-2: 审核不通过 check_Tag
	 * 分页查询产品
	 * @param page
	 * @param limit
	 * @param name
	 * @return
	 */
	@RequestMapping("/mdesignAll")
	@ResponseBody
	public String mdesignAll(@RequestParam(defaultValue = "1") int page,
			@RequestParam(defaultValue = "10") int limit,String name,String bh,String change){
		MDesignProcedure md = new MDesignProcedure();
		md.setChange_Tag(change);//变更状态
		md.setProduct_Name(name);
		md.setCheck_Tag(bh);//审核状态
		PageDemo<MDesignProcedure> pd = serivce.getAllMdesign(page, limit, md);
		String str = JSONArray.toJSONString(pd);
		return str;
	}
	/**
	 * 查询到东西修改
	 * @param id
	 * @param session
	 * @return
	 */
	@RequestMapping("/matrialdesign")
	public String matrialdesign(String id,HttpSession session) {
		MDesignProcedure md = serivce.findId(id);
		List<MDesignProcedureDetails> pd = mdserivce.findList(id);
		session.setAttribute("md", md);
		session.setAttribute("MdesignProcedure", pd);
		return "matrialdesign";
	}
	
	/**
	 * 审核标志   S001-0: 等待审核     S001-1: 审核通过    S001-2: 审核不通过 check_Tag
	 * 审核产品设计
	 * @param page
	 * @param limit
	 * @param name
	 * @return
	 */
	@RequestMapping("/mdesignshenhe")
	@ResponseBody
	public String mdesignshenhe(String id,String bh,@RequestParam(defaultValue = " ") String reason,HttpSession session){
		MDesignProcedure md = new MDesignProcedure();
		md.setDesign_Id(id);
		md.setCheck_Tag(bh);
		md.setCheck_Suggestion(reason);
		SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		md.setCheck_Time(formate.format(new Date()));
		String name =(String) session.getAttribute("username");
		md.setChecker(name);
		int count = serivce.mdesUpdate(md);
		String str = JSONArray.toJSONString(count);
		return str;
	}
	
	/**
	 * 审核标志   S001-0: 等待审核     S001-1: 审核通过    S001-2: 审核不通过 check_Tag
	 * 修改产品设计
	 * @param page
	 * @param limit
	 * @param name
	 * @return
	 */
	@RequestMapping("/updateMdesignProce")
	@ResponseBody
	public String updateMdesignProce(@ModelAttribute MDesignProcedure md,HttpSession session){
		SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		md.setChange_Time(formate.format(new Date()));//变更时间
		md.setCheck_Tag("等待审核");//审核状态
		md.setChange_Tag("更改");//变更转态
		String name =(String) session.getAttribute("username");
		md.setChanger(name);//变更人
		int count = serivce.mdesUpdate(md);
		String str = JSONArray.toJSONString(count);
		System.out.println(str);
		return str;
	}
	
	/**
	 * 添加产品设计
	 * @param md
	 * @param session
	 * @return
	 */
	@RequestMapping("/addMdesignProce")
	@ResponseBody
	public String addMdesignProce(@ModelAttribute MDesignProcedure md,HttpSession session){
		md.setDesign_Id("A"+OrderNo.NextOrderNo());//设计编号
		md.setProduct_Id("C"+OrderNo.NextOrderNo());//产品编号
		md.setCheck_Tag("等待审核");//等待审核
		md.setDesign_Module_Tag("未设计");//工序物料设计标志 
		md.setDesign_Module_Change_Tag("未变更");//工序物料变更标志
		md.setChange_Tag("未变更");//变更标志
		SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		md.setRegister_Time(formate.format(new Date()));
		String name =(String) session.getAttribute("username");
		md.setChecker(name);
		int count = serivce.mdesadd(md);
		String str = JSONArray.toJSONString(count);
		System.out.println(str);
		return str;
	}
	
}
