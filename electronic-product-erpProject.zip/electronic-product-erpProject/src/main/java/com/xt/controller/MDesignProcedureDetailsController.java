package com.xt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.xt.pojo.MDesignProcedureDetails;
import com.xt.service.MDesignProcedureDetailsService;

/**
 * 产品设计详情控制类
 * @author asus
 *罗文涛
 */
@Controller
public class MDesignProcedureDetailsController {
	@Autowired
	MDesignProcedureDetailsService serivce;
	
	/**
	 * 查询产品
	 * @param page
	 * @param limit
	 * @param name
	 * @return
	 */
	@RequestMapping("/mdesignDetailsAll")
	@ResponseBody
	public String mdesignAll(String name){
		System.out.println(name);
		List<MDesignProcedureDetails> pd = serivce.findList(name);
		String str = JSONArray.toJSONString(pd);
		return str;
	}
	
}
