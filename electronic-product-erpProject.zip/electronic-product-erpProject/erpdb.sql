/*
 Navicat Premium Data Transfer

 Source Server         : MyFirst
 Source Server Type    : MySQL
 Source Server Version : 50515
 Source Host           : localhost:3306
 Source Schema         : erpdb

 Target Server Type    : MySQL
 Target Server Version : 50515
 File Encoding         : 65001

 Date: 16/04/2020 17:35:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for d_config_file_kind
-- ----------------------------
DROP TABLE IF EXISTS `d_config_file_kind`;
CREATE TABLE `d_config_file_kind`  (
  `id` int(11) NOT NULL COMMENT '序号',
  `p_id` int(11) NULL DEFAULT NULL COMMENT '父级序号',
  `kind_id` varchar(0) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '分类编号',
  `kind_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分类名称',
  `kind_level` int(11) NULL DEFAULT NULL COMMENT '级别',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for d_file
-- ----------------------------
DROP TABLE IF EXISTS `d_file`;
CREATE TABLE `d_file`  (
  `id` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `factory_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_nick` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_class` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `personal_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `personal_value` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `provider_group` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `warranty` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `twin_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `twin_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lifecycle` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `list_price` double(12, 2) NOT NULL,
  `cost_price` double(12, 2) NOT NULL,
  `real_cost_price` double(12, 2) NULL DEFAULT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `responsible_person` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `changer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `change_time` date NULL DEFAULT NULL,
  `change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price_change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `file_change_amount` int(11) NULL DEFAULT NULL,
  `delete_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_module_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_procedure_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_cell_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for d_module
-- ----------------------------
DROP TABLE IF EXISTS `d_module`;
CREATE TABLE `d_module`  (
  `id` int(6) NOT NULL,
  `design_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `designer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `module_describe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price_sum` double(12, 2) NOT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `changer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `change_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for d_module_details
-- ----------------------------
DROP TABLE IF EXISTS `d_module_details`;
CREATE TABLE `d_module_details`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_describe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `residual_amount` double(12, 2) NULL DEFAULT NULL,
  `cost_price` double(12, 2) NOT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_apply
-- ----------------------------
DROP TABLE IF EXISTS `m_apply`;
CREATE TABLE `m_apply`  (
  `id` int(6) NOT NULL,
  `apply_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_describe` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `designer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remark` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_suggestion` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `manufacture_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_design_procedure
-- ----------------------------
DROP TABLE IF EXISTS `m_design_procedure`;
CREATE TABLE `m_design_procedure`  (
  `id` int(6) NOT NULL,
  `design_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `first_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `procedure_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `module_cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `designer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_suggestion` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `changer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `change_time` date NULL DEFAULT NULL,
  `change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_module_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_module_change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_design_procedure_details
-- ----------------------------
DROP TABLE IF EXISTS `m_design_procedure_details`;
CREATE TABLE `m_design_procedure_details`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `procedure_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `procedure_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `labour_hour_amount` double(12, 2) NOT NULL,
  `procedure_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cost_price` double(12, 2) NOT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `module_subtotal` double(12, 2) NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `design_module_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `design_module_change_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_design_procedure_module
-- ----------------------------
DROP TABLE IF EXISTS `m_design_procedure_module`;
CREATE TABLE `m_design_procedure_module`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `product_describe` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price` double(12, 2) NOT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_manufacture
-- ----------------------------
DROP TABLE IF EXISTS `m_manufacture`;
CREATE TABLE `m_manufacture`  (
  `id` int(6) NOT NULL,
  `manufacture_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `tested_amount` double(12, 2) NULL DEFAULT NULL,
  `apply_id_group` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `module_cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `real_module_cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `labour_cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `real_labour_cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `designer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `remark` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `manufacture_procedure_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_procedure
-- ----------------------------
DROP TABLE IF EXISTS `m_procedure`;
CREATE TABLE `m_procedure`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `procedure_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `procedure_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `labour_hour_amount` double(12, 2) NULL DEFAULT NULL,
  `real_labour_hour_amount` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `real_subtotal` double(12, 2) NULL DEFAULT NULL,
  `module_subtotal` double(12, 2) NULL DEFAULT NULL,
  `real_module_subtotal` double(12, 2) NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `demand_amount` double(12, 2) NULL DEFAULT NULL,
  `real_amount` double(12, 2) NULL DEFAULT NULL,
  `procedure_finish_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `procedure_transfer_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_procedure_module
-- ----------------------------
DROP TABLE IF EXISTS `m_procedure_module`;
CREATE TABLE `m_procedure_module`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `amount` double(12, 2) NULL DEFAULT NULL,
  `renew_amount` double(12, 2) NULL DEFAULT NULL,
  `real_amount` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `real_subtotal` double(12, 2) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_procedure_moduling
-- ----------------------------
DROP TABLE IF EXISTS `m_procedure_moduling`;
CREATE TABLE `m_procedure_moduling`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `amount` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for m_proceduring
-- ----------------------------
DROP TABLE IF EXISTS `m_proceduring`;
CREATE TABLE `m_proceduring`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `details_number` int(6) NOT NULL,
  `procedure_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `procedure_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `labour_hour_amount` double(12, 2) NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `procedure_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reg_count` double(12, 2) NOT NULL,
  `procedure_responsible_person` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for permission_role
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role`  (
  `rid` int(11) NULL DEFAULT NULL,
  `pid` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of permission_role
-- ----------------------------
INSERT INTO `permission_role` VALUES (1, 1);
INSERT INTO `permission_role` VALUES (1, 2);
INSERT INTO `permission_role` VALUES (1, 3);
INSERT INTO `permission_role` VALUES (1, 4);
INSERT INTO `permission_role` VALUES (1, 5);
INSERT INTO `permission_role` VALUES (1, 6);
INSERT INTO `permission_role` VALUES (1, 7);
INSERT INTO `permission_role` VALUES (1, 8);
INSERT INTO `permission_role` VALUES (1, 9);
INSERT INTO `permission_role` VALUES (1, 10);
INSERT INTO `permission_role` VALUES (1, 11);
INSERT INTO `permission_role` VALUES (1, 12);
INSERT INTO `permission_role` VALUES (1, 13);
INSERT INTO `permission_role` VALUES (1, 14);
INSERT INTO `permission_role` VALUES (1, 15);
INSERT INTO `permission_role` VALUES (1, 16);
INSERT INTO `permission_role` VALUES (1, 17);
INSERT INTO `permission_role` VALUES (1, 18);
INSERT INTO `permission_role` VALUES (1, 19);
INSERT INTO `permission_role` VALUES (1, 20);
INSERT INTO `permission_role` VALUES (1, 21);
INSERT INTO `permission_role` VALUES (1, 22);
INSERT INTO `permission_role` VALUES (1, 23);
INSERT INTO `permission_role` VALUES (3, 19);
INSERT INTO `permission_role` VALUES (2, 18);
INSERT INTO `permission_role` VALUES (2, 21);
INSERT INTO `permission_role` VALUES (2, 23);
INSERT INTO `permission_role` VALUES (4, 17);
INSERT INTO `permission_role` VALUES (4, 22);

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `descn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `linkUrl` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL COMMENT '类型 0代表菜单。1代表权限',
  `parentMenu` int(255) NULL DEFAULT NULL COMMENT '父级菜单编号,0代表父级菜单',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, '产品档案管理', '产品的详细信息', 'userlist.jsp', 0, 0);
INSERT INTO `permissions` VALUES (2, '产品物料组成设计', '产品所需要的物料信息', 'roleslist.jsp', 0, 0);
INSERT INTO `permissions` VALUES (3, '安全库存配置管理', '安全库存配置管理信息', 'menuslist.jsp', 0, 0);
INSERT INTO `permissions` VALUES (4, '入库申请管理', '入库申请的一个操作', 'goodslist.jsp', 0, 0);
INSERT INTO `permissions` VALUES (5, '出入库调度管理', '出入库调度的操作', 'allUsers', 0, 0);
INSERT INTO `permissions` VALUES (6, '动态库存查询', '库存的一个查询', 'addUser', 0, 0);
INSERT INTO `permissions` VALUES (7, '产品生产工序设计', '产品生产工序设计的操作', 'updateUser', 0, 0);
INSERT INTO `permissions` VALUES (8, '工序物料设计', '工序物料设计的操作', 'delUser', 0, 0);
INSERT INTO `permissions` VALUES (9, '生产计划管理', '一个生产计划管理的操作', 'allRoles', 0, 0);
INSERT INTO `permissions` VALUES (10, '生产调度管理', '生产调度管理信息', 'addRole', 0, 0);
INSERT INTO `permissions` VALUES (11, '内部生产管理', '内部生产管理操作', 'updateRoles', 0, 0);
INSERT INTO `permissions` VALUES (12, '产品档案登记', '产品档案登记信息的操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (13, '产品档案登记复核', '产品档案登记复核信息的操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (14, '产品档案查询', '产品档案查询信息操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (15, '产品档案变更', '产品档案变更信息的操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (16, '产品档案删除', '产品档案删除信息操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (17, '档案删除恢复', '档案删除恢复信息操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (18, '产品档案永久删除', '产品档案永久删除信息的操作', NULL, 0, 1);
INSERT INTO `permissions` VALUES (19, '制定物料组成设计单', '制定物料组成设计单信息的操作', NULL, 0, 2);
INSERT INTO `permissions` VALUES (20, '物料组成设计单审核', '物料组成设计单审核信息的操作', NULL, 0, 2);
INSERT INTO `permissions` VALUES (21, '物料组成设计单查询', '物料组成设计单查询信息的操作', NULL, 0, 2);
INSERT INTO `permissions` VALUES (22, '物料组成设计单变更', '物料组成设计单变更信息的操作', NULL, 0, 2);
INSERT INTO `permissions` VALUES (23, '制定安全库存配置单', '制定安全库存配置单信息的操作', NULL, 0, 3);
INSERT INTO `permissions` VALUES (24, '安全库存配置单审核', '安全库存配置单审核信息的操作', NULL, 0, 3);
INSERT INTO `permissions` VALUES (25, '安全库存配置单查询', '安全库存配置单查询信息的操作', NULL, 0, 3);
INSERT INTO `permissions` VALUES (26, '安全库存配置单变更', '安全库存配置单变更信息的操作', NULL, 0, 3);
INSERT INTO `permissions` VALUES (27, '入库申请登记', '入库申请登记操作', NULL, 0, 4);
INSERT INTO `permissions` VALUES (28, '入库申请审核', '入库申请审核的操作', NULL, 0, 4);
INSERT INTO `permissions` VALUES (29, '入库申请查询', '入库申请查询', NULL, 0, 4);
INSERT INTO `permissions` VALUES (30, '制定出库单', '制定出库单的操作', NULL, 0, 5);
INSERT INTO `permissions` VALUES (31, '制定入库单', '制定入库单的操作', NULL, 0, 5);
INSERT INTO `permissions` VALUES (32, '查询统计', '查询统计的操作', NULL, 0, 6);
INSERT INTO `permissions` VALUES (33, '制定产品生产工序设计单', '制定产品生产工序设计单的操作', NULL, 0, 7);
INSERT INTO `permissions` VALUES (34, '产品生产工序设计单审核', '产品生产工序设计单审核的操作', NULL, 0, 7);
INSERT INTO `permissions` VALUES (35, '产品生产工序设计单查询', '产品生产工序设计单查询的操作', NULL, 0, 7);
INSERT INTO `permissions` VALUES (36, '产品生产工序设计单变更', '产品生产工序设计单变更的操作', NULL, 0, 7);
INSERT INTO `permissions` VALUES (37, '制定工序物料设计单', '制定工序物料设计单', NULL, 0, 8);
INSERT INTO `permissions` VALUES (38, '工序物料设计单审核', '工序物料设计单审核的操作', NULL, 0, 8);
INSERT INTO `permissions` VALUES (39, '工序物料设计单查询', '工序物料设计单查询的操作', NULL, 0, 8);
INSERT INTO `permissions` VALUES (40, '工序物料设计单变更', '工序物料设计单变更的操作', NULL, 0, 8);
INSERT INTO `permissions` VALUES (41, '新发生生产计划登记', '新发生生产计划登记的操作', NULL, 0, 9);
INSERT INTO `permissions` VALUES (42, '生产计划审核', '生产计划审核的操作', NULL, 0, 9);
INSERT INTO `permissions` VALUES (43, '生产计划查询', '生产计划查询', NULL, 0, 9);
INSERT INTO `permissions` VALUES (44, '制定生产派工单', '制定生产派工单的操作', NULL, 0, 10);
INSERT INTO `permissions` VALUES (45, '生产派工单审核', '生产派工单审核的操作', NULL, 0, 10);
INSERT INTO `permissions` VALUES (46, '生产派工单查询', '生产派工单查询的操作', NULL, 0, 10);
INSERT INTO `permissions` VALUES (47, '生产登记', '生产登记的操作', NULL, 0, 11);
INSERT INTO `permissions` VALUES (48, '生产登记复核', '生产登记复核的操作', NULL, 0, 11);
INSERT INTO `permissions` VALUES (49, '生产查询', '生产查询的操作', NULL, 0, 11);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `descinfo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'CEO', '公司的老大，具有所有管理权限', '2020-01-06 18:43:11');
INSERT INTO `roles` VALUES (2, '质检主管', '监督、审核品管类别、检验项目、及时录入与更新。', '2020-01-09 18:43:11');
INSERT INTO `roles` VALUES (3, '库管', '仓库的管理员，维护仓库的', '2020-01-14 18:43:11');
INSERT INTO `roles` VALUES (4, '系统管理员', '一般的员工', '2020-01-15 18:43:11');

-- ----------------------------
-- Table structure for s_cell
-- ----------------------------
DROP TABLE IF EXISTS `s_cell`;
CREATE TABLE `s_cell`  (
  `id` int(6) NOT NULL,
  `store_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `first_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `second_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `third_kind_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `min_amount` double(12, 2) NOT NULL,
  `max_amount` double(12, 2) NOT NULL,
  `max_capacity_amount` double(12, 2) NOT NULL,
  `amount` double(12, 2) NOT NULL,
  `config` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for s_gather
-- ----------------------------
DROP TABLE IF EXISTS `s_gather`;
CREATE TABLE `s_gather`  (
  `id` int(6) NOT NULL,
  `gather_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `storer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `reasonexact` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount_sum` double(12, 2) NULL DEFAULT NULL,
  `cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `gathered_amount_sum` double(12, 2) NULL DEFAULT NULL,
  `remark` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `attemper` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `attemper_time` date NULL DEFAULT NULL,
  `store_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for s_gather_details
-- ----------------------------
DROP TABLE IF EXISTS `s_gather_details`;
CREATE TABLE `s_gather_details`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `gathered_amount` double(12, 2) NULL DEFAULT NULL,
  `gather_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for s_pay
-- ----------------------------
DROP TABLE IF EXISTS `s_pay`;
CREATE TABLE `s_pay`  (
  `id` int(6) NOT NULL,
  `pay_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `storer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `reason` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `reasonexact` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount_sum` double(12, 2) NOT NULL,
  `cost_price_sum` double(12, 2) NULL DEFAULT NULL,
  `paid_amount_sum` double(12, 2) NULL DEFAULT NULL,
  `remark` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `register_time` date NULL DEFAULT NULL,
  `checker` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `check_time` date NULL DEFAULT NULL,
  `check_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `attemper` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `attemper_time` date NULL DEFAULT NULL,
  `store_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for s_pay_details
-- ----------------------------
DROP TABLE IF EXISTS `s_pay_details`;
CREATE TABLE `s_pay_details`  (
  `id` int(6) NOT NULL,
  `parent_id` int(6) NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_describe` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `amount` double(12, 2) NOT NULL,
  `amount_unit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cost_price` double(12, 2) NULL DEFAULT NULL,
  `subtotal` double(12, 2) NULL DEFAULT NULL,
  `paid_amount` double(12, 2) NULL DEFAULT NULL,
  `pay_tag` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sys_codes
-- ----------------------------
DROP TABLE IF EXISTS `sys_codes`;
CREATE TABLE `sys_codes`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `PARENT_ID` int(11) NOT NULL COMMENT '父级序号',
  `CODE_ID` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '代码编号',
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '代码名称',
  `STATUS` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '状态',
  `DEF_VALUENOT` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '默认值',
  `DESCNNOT` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '基础代码表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sys_logs
-- ----------------------------
DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE `sys_logs`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `LOGIN_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名称',
  `PRIORITY` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '级别',
  `LOG_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '时间',
  `CLASS` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '类名',
  `METHOD` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '方法名',
  `MSG` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '信息',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '日志信息' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `u_id` int(11) NOT NULL,
  `r_id` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES (1, 1);
INSERT INTO `user_role` VALUES (2, 1);
INSERT INTO `user_role` VALUES (5, 4);
INSERT INTO `user_role` VALUES (6, 4);
INSERT INTO `user_role` VALUES (8, 4);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `u_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码加密盐值',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `u_status` int(11) NULL DEFAULT 1 COMMENT '1 为可用，  2为禁用',
  `u_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`u_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'yl', '男', '1ce10f75440b43cb186f407a5042419a', 'yl', '17674579134', 1, '2020-01-06 09:52:32');
INSERT INTO `users` VALUES (2, 'yh', '女', '479c7373b5b568d933452ea8c0b5e787', 'yh', '17876787467', 1, '2020-02-02 15:52:13');
INSERT INTO `users` VALUES (3, '小米', '男', '0b99f44d4d1011f47c4db393fc5b44b9', 'xm', '13487876478', 1, '2020-02-04 11:45:13');
INSERT INTO `users` VALUES (5, 'xz', '男', '579f09b7758eb74b53054fc217c47dfd', 'xz', '17878767839', 1, '2020-02-07 14:02:09');
INSERT INTO `users` VALUES (6, 'admin', '男', '25d0aca744c0af6cc5652626a992f3e4', 'ad', '17674579134', 1, '2020-02-10 13:56:48');
INSERT INTO `users` VALUES (8, 'yl1', '男', '9e6636bbac4bac46f3e5dd106409d89c', 'yl1', '17674579134', 1, '2020-02-10 14:38:13');
INSERT INTO `users` VALUES (9, 'lwt', '男', '8a3e9d15bfdb5f8e604f968f368ed35f', 'lwt', '17673425041', 1, '2020-02-10 15:03:12');

SET FOREIGN_KEY_CHECKS = 1;
